#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_client = new QMqttClient(this);
    m_client->setHostname("test.mosquitto.org");
    m_client->setPort(1883);



    connect(m_client, &QMqttClient::connected, this, &MainWindow::connectSuccessSlot);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::connectSuccessSlot()
{
    QMessageBox::information(this, "连接提示", "连接成功");

    m_client->subscribe(m_strPubTopic1);
    m_client->subscribe(m_strPubTopic2);
    m_client->subscribe(m_strPubTopic3);

    /* 消息接受成功槽函数 */
    connect(m_client, &QMqttClient::messageReceived, this, &MainWindow::recvMessageSlot);

    connect(m_client, &QMqttClient::disconnected, this, [this]()
    {
        QMessageBox::warning(this, "连接提示", "服务器断开");
    });

}
void MainWindow::recvMessageSlot(const QByteArray &message, const QMqttTopicName &topic)
{
    //距离
    if (topic.name() == m_strPubTopic1) {
           QString msg = message.trimmed();
           ui->label->setText(msg);
       }
    //温度
    if (topic.name() == m_strPubTopic2) {
           QString msg = message.trimmed();
           ui->label_2->setText(msg);
       }
    //湿度
    if (topic.name() == m_strPubTopic3) {
           QString msg = message.trimmed();
           ui->label_3->setText(msg);
       }
}

void MainWindow::on_pushButton_clicked()
{
    if (m_client->state() == QMqttClient::Connected) // 使用 QMqttClient 的状态枚举
        {
            // 如果已经连接，执行断开操作
            m_client->disconnectFromHost();
            // 可选：更新按钮文本或状态提示
             ui->pushButton->setText("连接服务器");
//             QMessageBox::information(this, "提示", "已断开连接");
//             ui->label_4->setText("断开");
        }
        else
        {
            // 如果未连接，执行连接操作
            m_client->connectToHost();
            // 可选：更新按钮文本或状态提示
             ui->pushButton->setText("断开服务器");
//             QMessageBox::information(this, "提示", "正在尝试连接...");
        }
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{

    // 将滑块的值转换为字符串并发布到MQTT主题
    QByteArray payload = QByteArray::number(value);
    QMqttTopicName topic("sg90");

    // 发布消息
    m_client->publish(topic, payload);
}

void MainWindow::on_pushButton_2_clicked()
{
    QMqttTopicName topic("sensors");
    m_client->publish(topic, "dht11");
    m_client->publish(topic, "sr04");
}
