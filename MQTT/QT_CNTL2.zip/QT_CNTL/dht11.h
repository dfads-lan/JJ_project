#ifndef DHT11_H
#define DHT11_H

void dht11_init(void);
int dht11_read(char *humi, char *temp);
int dht11_close();


extern char humi_data[20];
extern char temp_data[20];
extern char humi;
extern char temp;




#endif // DHT11_H
