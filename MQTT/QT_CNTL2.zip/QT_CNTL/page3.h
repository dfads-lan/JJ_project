#ifndef PAGE3_H
#define PAGE3_H

#include <QWidget>
#include <QSerialPort>
#include <QSlider>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <string.h>
#include <sys/mman.h>
#include <signal.h>
#include <poll.h>
#include <linux/fb.h>
#include <stdlib.h>
#include <string.h>

//#include "page1.h"
//#include "page2.h"
//#include "photo.h"

namespace Ui {
class page3;
}

class page3 : public QWidget
{
    Q_OBJECT

public:
    explicit page3(QWidget *parent = nullptr);
    ~page3();

signals:
    void back();

public slots:

    void on_slider_valueChanged(int value);


private:
    Ui::page3 *ui;
    QSerialPort serialPort;
};

#endif // PAGE3_H
