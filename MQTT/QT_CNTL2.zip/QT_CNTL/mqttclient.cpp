#include "mqttclient.h"

MqttClient::MqttClient(QObject *parent) : QObject(parent)
{
    m_client = new QMqttClient(this);

    connect(m_client, &QMqttClient::connected, this, &MqttClient::onConnected);
    connect(m_client, &QMqttClient::messageReceived, this, &MqttClient::onMessageReceived);
}

void MqttClient::connectToServer(const QString &host, quint16 port)
{
    m_client->setHostname(host);
    m_client->setPort(port);
    m_client->connectToHost();
}

void MqttClient::subscribe(const QString &topic)
{
    if (m_client->state() == QMqttClient::Connected) {
        m_client->subscribe(topic);
    }
}

void MqttClient::publish(const QString &topic, const QString &message)
{
    if (m_client->state() == QMqttClient::Connected) {
        m_client->publish(topic, message.toUtf8());
    }
}

void MqttClient::onConnected()
{
    qDebug() << "Connected to MQTT broker";
}

void MqttClient::onMessageReceived(const QByteArray &message, const QMqttTopicName &topic)
{
    emit messageReceived(topic.name(), QString::fromUtf8(message));
}
