#include "photo.h"
#include "ui_photo.h"

photo::photo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::photo)
{
    ui->setupUi(this);


    dir.setPath("./photo/"); // 设置目录路径
    dir.setFilter(QDir::Files | QDir::NoDotAndDotDot); // 过滤条件，只获取文件
    dir.setNameFilters(QStringList() << "*.jpg"); // 文件名过滤，只获取jpg文件
    dir.setSorting(QDir::Time | QDir::Reversed);  // 根据修改时间进行排序，逆序排列
    fileList = dir.entryList(); // 获取文件列表

    //先显示一张图片
    if(fileList.length() > 0){
        QString filePath = dir.filePath(fileList[currentIndex]); // 获取文件路径
        QPixmap pixmap(filePath); // 创建图片对象
        ui->label->setPixmap(pixmap); // 在控件上显示图片
        currentIndex++; // 更新当前显示的文件索引
        if (currentIndex >= fileList.size()) {
            currentIndex = 0;
        }
    }

    connect(ui->pushButton_back, &QPushButton::clicked,[=](){
        emit this->back();
    });

}

photo::~photo()
{
    delete ui;
}



void photo::loadAndDisplayImage(int newIndex)
{
    if (fileList.isEmpty()) {
        QMessageBox::warning(this, "提示", "没有照片可供显示！");
        return;
    }

    // 确保索引在有效范围内
    newIndex = newIndex % fileList.size();
    if (newIndex < 0) {
        newIndex += fileList.size();
    }

    // 获取文件路径
    QString filePath = dir.filePath(fileList[newIndex]);

    // 加载图片
    QPixmap pixmap(filePath);
    if (pixmap.isNull()) {
        QMessageBox::warning(this, "加载失败", "无法加载照片，请检查文件是否损坏！");
        return;
    }

    // 显示图片
    ui->label->setPixmap(pixmap);

    // 更新当前索引
    currentIndex = newIndex;
}

void photo::on_pushButton_up_clicked()
{
    if (fileList.isEmpty()) {
        QMessageBox::warning(this, "提示", "没有照片可供显示！");
        return;
    }

    // 更新索引为上一张照片
    int newIndex = currentIndex - 1;
    loadAndDisplayImage(newIndex);
}

void photo::on_pushButton_next_clicked()
{
    if (fileList.isEmpty()) {
        QMessageBox::warning(this, "提示", "没有照片可供显示！");
        return;
    }

    // 更新索引为下一张照片
    int newIndex = currentIndex + 1;
    loadAndDisplayImage(newIndex);
}

void photo::on_pushButton_back_clicked()
{
//    this->close();
//    page1 *v = new page1();   //new会分配内存
//    v->show();
}


void photo::on_delete_2_clicked()
{
    // 检查文件列表是否为空
    if (fileList.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "没有照片可以删除！");
        return;
    }

    // 获取当前照片的路径
    QString currentFilePath = dir.filePath(fileList[currentIndex]);

    // 确认是否删除
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "删除照片", "确定要删除这张照片吗？",
                                   QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        // 尝试删除文件
        if (QFile::remove(currentFilePath)) {
            QMessageBox::information(this, "删除成功", "照片已成功删除！");

            // 从文件列表中移除当前照片
            fileList.removeAt(currentIndex);

            // 更新索引
            if (currentIndex >= fileList.size()) {
                currentIndex = fileList.size() - 1; // 如果删除的是最后一张照片，索引指向倒数第二张
            }

            // 更新显示
            if (!fileList.isEmpty()) {
                QString nextFilePath = dir.filePath(fileList[currentIndex]);
                QPixmap pixmap(nextFilePath);
                ui->label->setPixmap(pixmap);
            } else {
                ui->label->clear(); // 如果没有照片了，清空显示区域
            }
        } else {
            QMessageBox::critical(this, "删除失败", "无法删除照片，请检查文件权限！");
        }
    }
}




