#ifndef LED_H
#define LED_H
void led_init(void);
void led_control(int on);
#endif // LED_H
