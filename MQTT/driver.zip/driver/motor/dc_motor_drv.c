#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/pwm.h>
#include <linux/uaccess.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/errno.h>

/* 主设备号 */
static int major = 0;
static struct class *dc_motor_class;       // 设备类
static struct pwm_device *dc_motor_pwm;    // PWM结构体操作指针

/* 打开设备 */
static int dc_motor_open(struct inode *inode, struct file *file)
{
    printk("====%s====\n", __FUNCTION__);

    pwm_config(dc_motor_pwm, 0, 20000000);          // 初始占空比为0，周期20ms
    pwm_set_polarity(dc_motor_pwm, PWM_POLARITY_NORMAL); // 设置PWM极性
    pwm_enable(dc_motor_pwm);

    return 0;
}

/* 写入设备 */
static ssize_t dc_motor_write(struct file *filp, const char __user *buf, size_t size, loff_t *offset)
{
    int ret;
    unsigned char duty_cycle; // 占空比 (0-100)

    printk("====%s====\n", __FUNCTION__);

    if (size != 1) {
        printk("Invalid input size\n");
        return -EINVAL;
    }

    ret = copy_from_user(&duty_cycle, buf, size);
    if (ret) {
        printk("Failed to copy data from user\n");
        return -EFAULT;
    }

    if (duty_cycle > 100) {
        printk("Invalid duty cycle: %d\n", duty_cycle);
        return -EINVAL;
    }

    // 设置PWM占空比
    pwm_config(dc_motor_pwm, duty_cycle * 200000, 20000000); // 占空比 = duty_cycle%

    return size;
}

/* 释放设备 */
static int dc_motor_release(struct inode *inode, struct file *filp)
{
    printk("====%s====\n", __FUNCTION__);

    pwm_disable(dc_motor_pwm);

    return 0;
}

/* 定义file_operations结构体 */
static struct file_operations dc_motor_fops = {
    .owner   = THIS_MODULE,
    .open    = dc_motor_open,
    .write   = dc_motor_write,
    .release = dc_motor_release,
};

/* probe函数 */
static int dc_motor_probe(struct platform_device *pdev)
{
    printk("====%s====\n", __FUNCTION__);

    /* 注册字符设备 */
    major = register_chrdev(0, "dc_motor", &dc_motor_fops);
    if (major < 0) {
        printk("Failed to register chrdev\n");
        return major;
    }

    dc_motor_class = class_create(THIS_MODULE, "dc_motor_class");
    if (IS_ERR(dc_motor_class)) {
        unregister_chrdev(major, "dc_motor");
        return PTR_ERR(dc_motor_class);
    }

    device_create(dc_motor_class, NULL, MKDEV(major, 0), NULL, "dc_motor");

    /* 从设备树获取PWM设备 */
    dc_motor_pwm = devm_of_pwm_get(&pdev->dev, pdev->dev.of_node, NULL);
    if (IS_ERR(dc_motor_pwm)) {
        dev_err(&pdev->dev, "Failed to get PWM device\n");
        device_destroy(dc_motor_class, MKDEV(major, 0));
        class_destroy(dc_motor_class);
        unregister_chrdev(major, "dc_motor");
        return PTR_ERR(dc_motor_pwm);
    }

    dev_info(&pdev->dev, "DC motor driver initialized successfully\n");
    return 0;
}

/* remove函数 */
static int dc_motor_remove(struct platform_device *pdev)
{
    printk("====%s====\n", __FUNCTION__);

    device_destroy(dc_motor_class, MKDEV(major, 0));
    class_destroy(dc_motor_class);
    unregister_chrdev(major, "dc_motor");

    return 0;
}

/* 设备树匹配表 */
static const struct of_device_id dc_motor_match_table[] = {
    {.compatible = "hc-dc-motor"},
    {},
};

/* 定义platform_driver */
static struct platform_driver dc_motor_driver = {
    .driver = {
        .name = "dc_motor",
        .of_match_table = dc_motor_match_table,
    },
    .probe = dc_motor_probe,
    .remove = dc_motor_remove,
};

/* 模块初始化 */
static int __init dc_motor_driver_init(void)
{
    printk("====%s====\n", __FUNCTION__);
    return platform_driver_register(&dc_motor_driver);
}

/* 模块退出 */
static void __exit dc_motor_driver_exit(void)
{
    printk("====%s====\n", __FUNCTION__);
    platform_driver_unregister(&dc_motor_driver);
}

module_init(dc_motor_driver_init);
module_exit(dc_motor_driver_exit);

MODULE_LICENSE("GPL");