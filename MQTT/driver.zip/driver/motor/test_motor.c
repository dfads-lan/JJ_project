#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define MOTOR_DEVICE "/dev/dc_motor"

// 设置电机速度（0 表示停止，1-100 表示速度百分比）
void motor_set_speed(int fd, unsigned int speed) {
    if (speed > 100) {
        fprintf(stderr, "Speed must be between 0 and 100.\n");
        return;
    }

    unsigned char command = (unsigned char)speed;

    if (write(fd, &command, 1) < 0) {
        perror("Failed to set motor speed");
    } else {
        if (speed == 0) {
            printf("Motor stopped.\n");
        } else {
            printf("Motor speed set to %u%%.\n", speed);
        }
    }
}

int main(int argc, char *argv[]) {
    int fd;

    // 打开电机设备节点
    fd = open(MOTOR_DEVICE, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open motor device");
        return EXIT_FAILURE;
    }

    printf("Testing motor driver...\n");

    // 启动电机并设置速度为 30%
    motor_set_speed(fd, 30);
    sleep(2);

    // 设置速度为 70%
    motor_set_speed(fd, 70);
    sleep(2);

    // 停止电机
    motor_set_speed(fd, 0);

    // 关闭设备节点
    close(fd);

    printf("Motor driver test completed.\n");
    return EXIT_SUCCESS;
}