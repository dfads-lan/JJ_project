#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <linux/input.h>


int main(void)
{
	int fd;
	unsigned int data;

	// struct input_event data;
	
	/* 2. 打开文件 */
	fd = open("/dev/xf_hs0038", O_RDWR);
	if (fd == -1)
	{
		printf("can not open file /dev/xf_hs0038\n");
		return ;
	}

	while(1)
	{
		if (read(fd, &data, 4) == 4)
		{
			// printf("get IR code  :\n");
			// printf(" Type: 0x%x\n", data.type);
			// printf(" Code: 0x%x\n", data.code);
			printf(" Val : %d\n", data);
		}
		else 
		{
			printf("get IR code: -1\n");
		}
	}
	
	close(fd);
	
	return ;
}


