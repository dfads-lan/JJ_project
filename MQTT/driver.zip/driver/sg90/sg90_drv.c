﻿#include <linux/module.h>
#include <linux/poll.h>
#include "linux/jiffies.h"
#include <linux/delay.h>

#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/stat.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/tty.h>
#include <linux/kmod.h>
#include <linux/gfp.h>
#include <linux/gpio/consumer.h>
#include <linux/platform_device.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/slab.h>
#include <linux/fcntl.h>
#include <linux/timer.h>
#include <linux/of.h>
#include <linux/gpio.h>
#include <linux/kthread.h>
#include <linux/pwm.h>
#include <linux/uaccess.h>

/* 主设备号                                                                 */
static int major = 0;
static struct class *sg90_class;    // 设备类
static struct pwm_device *sg90_pwm_device;  // PWM结构体操作指针


static ssize_t sg90_open(struct inode *inode, struct file *file )
{
    printk("====%s====\n", __FUNCTION__);

    pwm_config(sg90_pwm_device, 500000, 20000000);          // 设置PWM参数,初始角度，频率，单位ns
    pwm_set_polarity(sg90_pwm_device, PWM_POLARITY_NORMAL); // 设置PWM极性
    pwm_enable(sg90_pwm_device);

    return 0;
}

static ssize_t sg90_read(struct file *file, char __user *buf, size_t size, loff_t *offset)
{
    printk("====%s====\n", __FUNCTION__);

    return 0;
}


static ssize_t sg90_write(struct file *filp, const char __user *buf, size_t size, loff_t *offset)
{

    int ret;
    unsigned char data[1];

    printk("====%s====\n", __FUNCTION__);

    ret = copy_from_user(data, buf, size);
    pwm_config(sg90_pwm_device, 500000+data[0] * 100000/9, 20000000);

    return 0;
}

static int sg90_release(struct inode *node, struct file *filp)
{
    printk("====%s====\n", __FUNCTION__);

    // pwm_config(sg90_pwm_device, 500000, 20000000); 
    pwm_free(sg90_pwm_device);

    return 0;
}

/* 定义自己的file_operations结构体                                              */
static struct file_operations sg90_drv = {
	.owner	 = THIS_MODULE,
    .open    = sg90_open,
	.read    = sg90_read,
    .write   = sg90_write,
    .release = sg90_release,
};

static int sg90_probe(struct platform_device *pdev)
{

    printk("====%s====\n", __FUNCTION__);

    /* 注册file_operations 	*/
    major = register_chrdev(0, "sg90_chrdev", &sg90_drv);           /* /dev/gpio_desc */
    sg90_class = class_create(THIS_MODULE, "sg90_class");
    device_create(sg90_class, NULL, MKDEV(major, 0), NULL, "sg90"); /* /dev/sg90 */

    /* 从设备树获得硬件信息 */
    sg90_pwm_device = devm_of_pwm_get(&pdev->dev, pdev->dev.of_node, NULL);
    if (IS_ERR(sg90_pwm_device))
    {
        dev_err(&pdev->dev, "Failed to get PWM for sg90\n");
        return PTR_ERR(sg90_pwm_device);
    }



    dev_info(&pdev->dev, "=======sg90 initialized successfully=====\n");
    return 0;
}

static int sg90_remove(struct platform_device *pdev)
{

    printk("======%s=======\n", __FUNCTION__);

    device_destroy(sg90_class, MKDEV(major, 0));
    class_destroy(sg90_class);
    unregister_chrdev(major, "sg90_chrdev");

    return 0;
}

/* 定义设备树匹配表，用于识别和支持特定的字符设备驱动器 */
static const struct of_device_id sg90_match_table[] = {
    /* 匹配字符串 "fire,xxx" 用于标识 */
    {.compatible = "hc-sg90"},
    /* 空项作为匹配表的结束标志 */
    {},
};



/*  定义platform_driver */
static struct platform_driver sg90_driver = {
    /* 设置<驱动程序的名称>和<设备树匹配表> */
    .driver = {
        .name = "sg90",                     // 字符设备名
        .of_match_table = sg90_match_table, // 设置设备树匹配表，用于设备的匹配
    },
    .probe = sg90_probe,   // 设置探测函数，当设备被探测到时调用
    .remove = sg90_remove, // 设置移除函数，当设备被移除时调用

};

/* 在入口函数 */
static int __init sg90_platform_driver_init(void)
{
    int ret = 0;
    printk("====%s====\n", __FUNCTION__);

    ret = platform_driver_register(&sg90_driver); // 注册驱动程序

    return ret;
}


/* 有入口函数就应该有出口函数：卸载驱动程序时，就会去调用这个出口函数
 */
static void __exit sg90_platform_driver_exit(void)
{
    printk("====%s====\n", __FUNCTION__);

     platform_driver_unregister(&sg90_driver); // 销毁设备信息

}


/* 7. 其他完善：提供设备信息，自动创建设备节点                                     */

module_init(sg90_platform_driver_init);
module_exit(sg90_platform_driver_exit);

MODULE_LICENSE("GPL");


