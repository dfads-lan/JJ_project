#include "page3.h"
#include "ui_page3.h"


page3::page3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::page3)
{
    ui->setupUi(this);

    // 配置串口
    serialPort.setPortName("/dev/ttymxc2"); // 根据实际串口设备文件名修改
    serialPort.setBaudRate(QSerialPort::Baud115200);
    serialPort.setDataBits(QSerialPort::Data8);
    serialPort.setParity(QSerialPort::NoParity);
    serialPort.setStopBits(QSerialPort::OneStop);
    serialPort.setFlowControl(QSerialPort::NoFlowControl);


    if (!serialPort.open(QIODevice::ReadWrite))
    {
        QMessageBox::critical(this, "Error", "Failed to open serial port");
        return;
    }

}

page3::~page3()
{
    delete ui;
    serialPort.close();
}

void page3::on_pushButton_back_clicked()
{
    this->close();
    MainWindow *s = new MainWindow();
    s->show();
}

void page3::on_slider_valueChanged(int value)
{

    // 更新标签显示角度
    ui->label->setText(QString("Angle: %1").arg(value));

    // 发送角度值到STM32
    QByteArray data;
    data.append(static_cast<char>(value)); // 将角度值转换为字节
    serialPort.write(data); // 发送数据
}
