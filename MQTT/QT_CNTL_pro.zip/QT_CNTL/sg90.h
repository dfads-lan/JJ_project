#ifndef SG90_H
#define SG90_H

void sg90_init(void);
void sg90_control(int on);




#endif // SG90_H
