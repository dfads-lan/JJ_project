/********************************************************************************
** Form generated from reading UI file 'kimichat.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KIMICHAT_H
#define UI_KIMICHAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KimiChat
{
public:
    QLineEdit *lineEdit;
    QPushButton *sendButton;
    QTextEdit *textEdit;
    QPushButton *pushButton_back;

    void setupUi(QWidget *KimiChat)
    {
        if (KimiChat->objectName().isEmpty())
            KimiChat->setObjectName(QString::fromUtf8("KimiChat"));
        KimiChat->resize(800, 480);
        lineEdit = new QLineEdit(KimiChat);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(90, 270, 581, 141));
        sendButton = new QPushButton(KimiChat);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));
        sendButton->setGeometry(QRect(700, 360, 71, 41));
        textEdit = new QTextEdit(KimiChat);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(90, 10, 581, 231));
        pushButton_back = new QPushButton(KimiChat);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setGeometry(QRect(10, 20, 61, 41));

        retranslateUi(KimiChat);

        QMetaObject::connectSlotsByName(KimiChat);
    } // setupUi

    void retranslateUi(QWidget *KimiChat)
    {
        KimiChat->setWindowTitle(QApplication::translate("KimiChat", "Form", nullptr));
        sendButton->setText(QApplication::translate("KimiChat", "\345\217\221\351\200\201", nullptr));
        pushButton_back->setText(QApplication::translate("KimiChat", "\351\200\200\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KimiChat: public Ui_KimiChat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KIMICHAT_H
