/********************************************************************************
** Form generated from reading UI file 'photo.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PHOTO_H
#define UI_PHOTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_photo
{
public:
    QLabel *label_2;
    QLabel *label;
    QPushButton *pushButton_back;
    QPushButton *pushButton_up;
    QPushButton *pushButton_next;
    QPushButton *delete_2;

    void setupUi(QWidget *photo)
    {
        if (photo->objectName().isEmpty())
            photo->setObjectName(QString::fromUtf8("photo"));
        photo->resize(800, 480);
        label_2 = new QLabel(photo);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 800, 480));
        label = new QLabel(photo);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(160, 0, 481, 481));
        label->setLayoutDirection(Qt::LeftToRight);
        pushButton_back = new QPushButton(photo);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setGeometry(QRect(20, 20, 81, 41));
        pushButton_up = new QPushButton(photo);
        pushButton_up->setObjectName(QString::fromUtf8("pushButton_up"));
        pushButton_up->setGeometry(QRect(0, 150, 91, 181));
        pushButton_next = new QPushButton(photo);
        pushButton_next->setObjectName(QString::fromUtf8("pushButton_next"));
        pushButton_next->setGeometry(QRect(710, 140, 91, 191));
        delete_2 = new QPushButton(photo);
        delete_2->setObjectName(QString::fromUtf8("delete_2"));
        delete_2->setGeometry(QRect(720, 20, 61, 41));

        retranslateUi(photo);

        QMetaObject::connectSlotsByName(photo);
    } // setupUi

    void retranslateUi(QWidget *photo)
    {
        photo->setWindowTitle(QApplication::translate("photo", "Form", nullptr));
        label_2->setText(QString());
        label->setText(QApplication::translate("photo", "\346\227\240\345\233\276\347\211\207", nullptr));
        pushButton_back->setText(QApplication::translate("photo", "\350\277\224\345\233\236", nullptr));
        pushButton_up->setText(QApplication::translate("photo", "\344\270\212\344\270\200\345\274\240", nullptr));
        pushButton_next->setText(QApplication::translate("photo", "\344\270\213\344\270\200\345\274\240", nullptr));
        delete_2->setText(QApplication::translate("photo", "delete", nullptr));
    } // retranslateUi

};

namespace Ui {
    class photo: public Ui_photo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PHOTO_H
