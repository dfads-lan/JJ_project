#ifndef PAGE1_H
#define PAGE1_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QThread>

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <string.h>
#include <sys/mman.h>
#include <signal.h>
#include <poll.h>
#include <linux/fb.h>
#include <stdlib.h>
#include <string.h>

#include <QTimer>
#include <QUdpSocket>
#include <QCheckBox>

#define		video_width		640
#define 	video_height	480



class V4L2Thread;

namespace Ui {
class page1;
}

class page1 : public QWidget
{
    Q_OBJECT

public:
    explicit page1(QWidget *parent = nullptr);
    ~page1();

    V4L2Thread *v4l2Thread;

signals:
    void back();

private:
    Ui::page1 *ui;
    char *userbuff[4];        /* 存放摄像头设备内核缓冲区映射后的用户内存地址 */
    int userbuff_length[4];   /* 保存映射后的数据长度，释放缓存时要用 */
    int show_flag = 1;    /* 1:保存到本地   2:显示在lcd上 */
    int video_fd;
    int lcd_fd;
    int lcd_xres, lcd_yres;
    int lcd_realvirtual;

    int start = 0;

    QUdpSocket *udpSocket;  // 添加UDP Socket成员变量
    QHostAddress targetAddress;  // 目标地址
    quint16 targetPort;  // 目标端口

    QTimer *timer;
    QCheckBox *checkBox;

//    showphoto s;

    int v4l2_open();   //初始化相机参数
    int v4l2_close();

public slots:
    void video_show();

private slots:
    void on_pushButton_open_clicked();
    void on_pushButton_take_clicked();
    void on_pushButton_photos_clicked();
    void on_back_clicked();
    void on_checkBox_stateChanged(int arg1);
};



class V4L2Thread : public QThread {
    /* 用到信号槽即需要此宏定义 */
    Q_OBJECT

public:
     V4L2Thread(QWidget *parent = nullptr) {
        Q_UNUSED(parent);
     }
     /* 线程程序 */
    void run() override ;
    //void SetLables_sr501(QLabel *sr501_label);


private:

};


#endif // PAGE1_H
