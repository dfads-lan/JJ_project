#include "page_sr04.h"
#include "ui_page_sr04.h"
#include "sr04.h"

PageSR04::PageSR04(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PageSR04)
{
    ui->setupUi(this);

    /* 线程实例 */
    sr04Thread = new SR04Thread(this);
    sr04_label = ui->sr04_label;  // SR04文本框

    /* 连接线程的标签 */
    sr04Thread->SetLabel_sr04(sr04_label);

    /* 启动线程 */
    sr04Thread->start();

    connect(ui->backButton, &QPushButton::clicked, [=]() {
        /* 发一个信号返回主页面 */
        emit this->back();
    });
}

PageSR04::~PageSR04()
{
    // 停止线程
    sr04Thread->quit();  // 请求线程停止

    // 等待线程完成
    sr04Thread->wait();  // 等待线程结束

    // 删除线程对象
    delete sr04Thread;

    delete ui;
}

/* SR04线程实现 */
SR04Thread::SR04Thread(QObject *parent) : QThread(parent), sr04_label(nullptr) {}

void SR04Thread::SetLabel_sr04(QLabel *sr04_label)
{
    this->sr04_label = sr04_label;
}

void SR04Thread::run()
{
    float distance = 0.0;

    while (1) {
        int ret = sr04_read(&distance);
        if (ret == 0) {
            QString distanceText = QString("距离: %1 cm").arg(distance);
            sr04_label->setText(distanceText);
        } else {
            sr04_label->setText("读取失败");
        }

        msleep(500);  // 线程休眠0.5秒
    }
}
