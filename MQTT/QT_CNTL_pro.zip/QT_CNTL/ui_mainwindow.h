/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *camera;
    QPushButton *kimichat;
    QPushButton *motor;
    QPushButton *sg90;
    QPushButton *sr04;
    QLabel *label;
    QCheckBox *led;
    QLabel *label_2;
    QPushButton *subscribeButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 480);
        MainWindow->setStyleSheet(QString::fromUtf8("MainWindow{\n"
"border-image: url(:/Pictures/10010f000000799de12B0.jpg);}"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        camera = new QPushButton(centralwidget);
        camera->setObjectName(QString::fromUtf8("camera"));
        camera->setGeometry(QRect(100, 90, 91, 51));
        kimichat = new QPushButton(centralwidget);
        kimichat->setObjectName(QString::fromUtf8("kimichat"));
        kimichat->setGeometry(QRect(350, 90, 91, 51));
        motor = new QPushButton(centralwidget);
        motor->setObjectName(QString::fromUtf8("motor"));
        motor->setEnabled(false);
        motor->setGeometry(QRect(600, 90, 91, 51));
        sg90 = new QPushButton(centralwidget);
        sg90->setObjectName(QString::fromUtf8("sg90"));
        sg90->setGeometry(QRect(480, 90, 91, 51));
        sr04 = new QPushButton(centralwidget);
        sr04->setObjectName(QString::fromUtf8("sr04"));
        sr04->setGeometry(QRect(230, 90, 91, 51));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(530, 190, 231, 31));
        led = new QCheckBox(centralwidget);
        led->setObjectName(QString::fromUtf8("led"));
        led->setEnabled(true);
        led->setGeometry(QRect(430, 180, 89, 46));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(led->sizePolicy().hasHeightForWidth());
        led->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(12);
        led->setFont(font);
        led->setTabletTracking(false);
        led->setIconSize(QSize(40, 40));
        led->setCheckable(true);
        led->setChecked(false);
        led->setTristate(false);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(460, 20, 331, 51));
        subscribeButton = new QPushButton(centralwidget);
        subscribeButton->setObjectName(QString::fromUtf8("subscribeButton"));
        subscribeButton->setGeometry(QRect(320, 20, 81, 41));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 28));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        camera->setText(QApplication::translate("MainWindow", "camera", nullptr));
        kimichat->setText(QApplication::translate("MainWindow", "kimi-chat", nullptr));
        motor->setText(QApplication::translate("MainWindow", "motor", nullptr));
        sg90->setText(QApplication::translate("MainWindow", "sg90", nullptr));
        sr04->setText(QApplication::translate("MainWindow", "distance", nullptr));
        label->setText(QApplication::translate("MainWindow", "NAX", nullptr));
        led->setText(QApplication::translate("MainWindow", "led", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
        subscribeButton->setText(QApplication::translate("MainWindow", "\350\277\236\346\216\245\346\234\215\345\212\241\345\231\250", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
