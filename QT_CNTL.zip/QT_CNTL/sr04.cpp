#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>

#include <errno.h>
#include <QDebug>

#include "sr04.h"
static int fd_sr04;

/* sr04 初始化函数 */
void sr04_init(void)
{
    fd_sr04 = open("/dev/sr04", O_RDWR);
    if (fd_sr04 < 0)
    {
        qDebug() << "open /dev/sr04 failed" << endl;
    }
    else
    {
        qDebug() << "open /dev/sr04 successfully" << endl;
    }
}

/* sr04 读取距离函数 */
//int sr04_read(float *distance)
//int sr04_read(int ns)
//{
////    unsigned char data[4];
////    int ret;

////    ret = read(fd_sr04, data, 4);
////    if (ret < 0)
////    {
////        qDebug() << "read /dev/sr04 failed" << endl;
////        return -1;
////    }
//    if (read(fd_sr04, &ns, 4)==4){
//    qDebug() << ns*340/2/1000000 ;
//    // 假设返回的数据是一个 4 字节的浮点数
////    memcpy(distance, data, sizeof(float));
////    qDebug() << "Distance read from /dev/sr04:" << *distance << "cm";
//    }
//    else{
//        qDebug() << "read /dev/sr04 failed" << endl;
//    }


//    return 0;
//}
int sr04_read(int &ns)
{
    if (read(fd_sr04, &ns, 4) == 4)
    {
//        qDebug() << ns * 340 / 2 / 1000000;
    }
    else
    {
        qDebug() << "read /dev/sr04 failed" << endl;
        return -1; // 返回错误码
    }
    return 0; // 返回成功
}
/* sr04 关闭函数 */
int sr04_close(void)
{
    if (close(fd_sr04) < 0)
    {
        qDebug() << "close /dev/sr04 failed" << endl;
        return -1;
    }
    qDebug() << "close /dev/sr04 successfully" << endl;
    return 0;
}
