/********************************************************************************
** Form generated from reading UI file 'page3.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGE3_H
#define UI_PAGE3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_page3
{
public:
    QPushButton *pushButton_back;
    QLabel *label;
    QSlider *slider;

    void setupUi(QWidget *page3)
    {
        if (page3->objectName().isEmpty())
            page3->setObjectName(QString::fromUtf8("page3"));
        page3->resize(800, 480);
        pushButton_back = new QPushButton(page3);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setGeometry(QRect(20, 20, 71, 41));
        label = new QLabel(page3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 80, 251, 101));
        label->setAutoFillBackground(false);
        slider = new QSlider(page3);
        slider->setObjectName(QString::fromUtf8("slider"));
        slider->setGeometry(QRect(190, 240, 361, 61));
        slider->setMaximum(180);
        slider->setSingleStep(1);
        slider->setSliderPosition(2);
        slider->setOrientation(Qt::Horizontal);

        retranslateUi(page3);

        QMetaObject::connectSlotsByName(page3);
    } // setupUi

    void retranslateUi(QWidget *page3)
    {
        page3->setWindowTitle(QApplication::translate("page3", "Form", nullptr));
        pushButton_back->setText(QApplication::translate("page3", "\351\200\200\345\207\272", nullptr));
        label->setText(QApplication::translate("page3", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class page3: public Ui_page3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGE3_H
