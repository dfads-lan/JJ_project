/********************************************************************************
** Form generated from reading UI file 'page1.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGE1_H
#define UI_PAGE1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_page1
{
public:
    QPushButton *back;
    QPushButton *pushButton_open;
    QPushButton *pushButton_take;
    QPushButton *pushButton_photos;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QWidget *page1)
    {
        if (page1->objectName().isEmpty())
            page1->setObjectName(QString::fromUtf8("page1"));
        page1->setEnabled(true);
        page1->resize(800, 480);
        page1->setAutoFillBackground(false);
        back = new QPushButton(page1);
        back->setObjectName(QString::fromUtf8("back"));
        back->setGeometry(QRect(30, 30, 121, 51));
        pushButton_open = new QPushButton(page1);
        pushButton_open->setObjectName(QString::fromUtf8("pushButton_open"));
        pushButton_open->setGeometry(QRect(250, 40, 101, 41));
        pushButton_take = new QPushButton(page1);
        pushButton_take->setObjectName(QString::fromUtf8("pushButton_take"));
        pushButton_take->setGeometry(QRect(390, 40, 91, 41));
        pushButton_photos = new QPushButton(page1);
        pushButton_photos->setObjectName(QString::fromUtf8("pushButton_photos"));
        pushButton_photos->setGeometry(QRect(520, 40, 111, 41));
        label = new QLabel(page1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 110, 591, 321));
        label_2 = new QLabel(page1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(710, 50, 41, 31));

        retranslateUi(page1);

        QMetaObject::connectSlotsByName(page1);
    } // setupUi

    void retranslateUi(QWidget *page1)
    {
        page1->setWindowTitle(QApplication::translate("page1", "Form", nullptr));
        back->setText(QApplication::translate("page1", "\350\277\224\345\233\236\344\270\273\351\241\265", nullptr));
        pushButton_open->setText(QApplication::translate("page1", "\346\211\223\345\274\200\346\221\204\345\203\217\345\244\264", nullptr));
        pushButton_take->setText(QApplication::translate("page1", "\346\213\215\347\205\247", nullptr));
        pushButton_photos->setText(QApplication::translate("page1", "\347\233\270\345\206\214", nullptr));
        label->setText(QApplication::translate("page1", "5rggreg", nullptr));
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class page1: public Ui_page1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGE1_H
