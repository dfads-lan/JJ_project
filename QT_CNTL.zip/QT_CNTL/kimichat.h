#ifndef KIMICHAT_H
#define KIMICHAT_H

#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QMessageBox>

#include "mainwindow.h"

namespace Ui {
class KimiChat;
}

class KimiChat : public QWidget
{
    Q_OBJECT

public:
    explicit KimiChat(QWidget *parent = nullptr);
    ~KimiChat();

private slots:
    void on_sendButton_clicked();
    void onReplyFinished(QNetworkReply *reply);  // 网络请求完成事件

    void on_pushButton_back_clicked();

private:
    Ui::KimiChat *ui;
    QNetworkAccessManager *manager;  // 网络请求管理器
};

#endif // KIMICHAT_H
