#ifndef PAGE_SR04_H
#define PAGE_SR04_H

#include <QWidget>
#include <QLabel>
#include <QThread>

namespace Ui {
class PageSR04;
}

class SR04Thread : public QThread
{
    Q_OBJECT
public:
    explicit SR04Thread(QObject *parent = nullptr);
    void SetLabel_sr04(QLabel *sr04_label);
protected:
    void run() override;

private:
    QLabel *sr04_label;
};

class PageSR04 : public QWidget
{
    Q_OBJECT

public:
    explicit PageSR04(QWidget *parent = nullptr);
    ~PageSR04();

signals:
    void back();

private:
    Ui::PageSR04 *ui;
    SR04Thread *sr04Thread;
    QLabel *sr04_label;
};

#endif // PAGE_SR04_H
