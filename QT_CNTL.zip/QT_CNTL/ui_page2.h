/********************************************************************************
** Form generated from reading UI file 'page2.ui'
**
** Created by: Qt User Interface Compiler version 5.12.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGE2_H
#define UI_PAGE2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_page2
{
public:
    QPushButton *pushButton_back;
    QLabel *sr04_label;
    QLabel *label_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QCheckBox *checkBox;
    QLabel *label_6;

    void setupUi(QWidget *page2)
    {
        if (page2->objectName().isEmpty())
            page2->setObjectName(QString::fromUtf8("page2"));
        page2->resize(800, 480);
        pushButton_back = new QPushButton(page2);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setGeometry(QRect(30, 20, 81, 31));
        sr04_label = new QLabel(page2);
        sr04_label->setObjectName(QString::fromUtf8("sr04_label"));
        sr04_label->setGeometry(QRect(190, 170, 91, 21));
        label_3 = new QLabel(page2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(110, 170, 67, 17));
        label = new QLabel(page2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(340, 170, 67, 17));
        label_2 = new QLabel(page2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(340, 200, 67, 17));
        label_4 = new QLabel(page2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(410, 170, 67, 17));
        label_5 = new QLabel(page2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(410, 200, 67, 17));
        checkBox = new QCheckBox(page2);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(450, 80, 92, 23));
        label_6 = new QLabel(page2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(570, 80, 211, 41));

        retranslateUi(page2);

        QMetaObject::connectSlotsByName(page2);
    } // setupUi

    void retranslateUi(QWidget *page2)
    {
        page2->setWindowTitle(QApplication::translate("page2", "Form", nullptr));
        pushButton_back->setText(QApplication::translate("page2", "\350\277\224\345\233\236", nullptr));
        sr04_label->setText(QApplication::translate("page2", "N/A", nullptr));
        label_3->setText(QApplication::translate("page2", "\350\267\235\347\246\273\357\274\232", nullptr));
        label->setText(QApplication::translate("page2", "\346\270\251\345\272\246\357\274\232", nullptr));
        label_2->setText(QApplication::translate("page2", "\346\271\277\345\272\246\357\274\232", nullptr));
        label_4->setText(QApplication::translate("page2", "N/A", nullptr));
        label_5->setText(QApplication::translate("page2", "N/A", nullptr));
        checkBox->setText(QApplication::translate("page2", "\347\272\277\347\250\213\345\210\207\346\215\242", nullptr));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class page2: public Ui_page2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGE2_H
