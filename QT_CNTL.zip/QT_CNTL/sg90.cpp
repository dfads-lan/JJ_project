#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <poll.h>
#include <signal.h>
#include <stdlib.h>
#include <QDebug>

/*
 * ./sg90_test /dev/sg90 90
 *
 */

static int fd;

void sg90_init(void)
{
    fd = open("/dev/sg90", O_RDWR);
    if (fd < 0)
    {
        qDebug()<<"open /dev/sg90 failed";
    }
    qDebug()<<"open /dev/sg90 successfully " << endl;
}

void sg90_control(int on)
{
    unsigned char buf[1];
    buf[0] = on;
//    qDebug() << buf[0] << endl;

    write(fd, buf, 1);
//    sleep(3);
}
