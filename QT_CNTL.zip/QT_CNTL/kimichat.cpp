#include "kimichat.h"
#include "ui_kimichat.h"

KimiChat::KimiChat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::KimiChat)
{
    ui->setupUi(this);

    // 初始化网络请求管理器
    manager = new QNetworkAccessManager(this);
    connect(manager, &QNetworkAccessManager::finished, this, &KimiChat::onReplyFinished);


}

KimiChat::~KimiChat()
{
    delete ui;
}

void KimiChat::on_sendButton_clicked()
{
    // 获取用户输入的问题
    QString question = ui->lineEdit->text();
    if (question.isEmpty()) {
        QMessageBox::warning(this, "警告", "请输入问题！");
        return;
    }

    // 构造JSON请求体
    QJsonObject message;
    message["role"] = "user";
    message["content"] = question;

    QJsonArray messages;
    messages.append(message);

    QJsonObject json;
    json["model"] = "moonshot-v1-8k";  // 模型名称
    json["messages"] = messages;  // 将消息数组添加到JSON对象中
    json["temperature"] = 0.3;  // 温度参数
    json["max_tokens"] = 2048;  // 最大返回长度

    QByteArray data = QJsonDocument(json).toJson();

    // 构造请求
    QNetworkRequest request(QUrl("https://api.moonshot.cn"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "sk-BOHRdcPIkBgHBp0scNiGaCyKaVPfbBDVHC582JEehjnISKis");

    // 发送POST请求
    manager->post(request, data);
}




void KimiChat::onReplyFinished(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError) {
        // 获取响应数据
        QByteArray response = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(response);
        if (!doc.isNull() && doc.isObject()) {
            QJsonObject obj = doc.object();
            QString replyText = obj["choices"].toArray()[0].toObject()["message"].toObject()["content"].toString();
            ui->textEdit->append("Kimi: " + replyText);  // 显示Kimi的回复
        } else {
            ui->textEdit->append("Kimi: 无法解析响应数据");
        }
    } else {
        QString errorString = reply->errorString();
        ui->textEdit->append("Kimi: 网络请求失败：" + errorString);
        if (errorString.contains("Not Found")) {
            ui->textEdit->append("请检查API地址是否正确，或联系Kimi官方获取帮助。");
        } else if (errorString.contains("Connection refused")) {
            ui->textEdit->append("网络连接被拒绝，请检查网络配置或代理设置。");
        } else {
            ui->textEdit->append("其他错误，请检查网络或API Key是否正确。");
        }
    }
}

void KimiChat::on_pushButton_back_clicked()
{
    this->close();
    MainWindow *s = new MainWindow();
    s->show();
}
