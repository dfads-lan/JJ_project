#ifndef PAGE2_H
#define PAGE2_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QThread>

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <string.h>
#include <sys/mman.h>
#include <signal.h>
#include <poll.h>
#include <linux/fb.h>
#include <stdlib.h>
#include <string.h>
#include <QChart>     //图表类
#include <QChartView>   //图表视图类
#include <QLineSeries>
#include <QCheckBox>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

#include "sr04.h"
#include "dht11.h"
#include <QMutex>
#include "mainwindow.h"


// 创建继承自 QThread 的 SR04 线程类
class SR04Thread : public QThread
{
    Q_OBJECT

public:
//    explicit SR04Thread(QObject *parent = nullptr);
    SR04Thread(QWidget *parent = nullptr) {
            Q_UNUSED(parent);
         }
    void SetLabel_sr04(QLabel *label);
    void updateSR04Data(int state);
    void stop(); // 停止线程

signals:
    void resultReady(const QString &text);

protected:
    void run() override;

private:
    QLabel *sr04_label;

};


//DHT11线程类
class DHT11Thread : public QThread
{
    Q_OBJECT

public:
//    explicit DHT11Thread(QObject *parent = nullptr);
    DHT11Thread(QWidget *parent = nullptr) {
            Q_UNUSED(parent);
         }
    void SetLables(QLabel *labelHumi, QLabel *labelTemp);
    void updateDHT11Data(int state);
    void stop(); // 停止线程

signals:
    void resultReady(const QString &tempText, const QString &humiText);

protected:
    void run() override;

private:
    QLabel *labelHumi;
    QLabel *labelTemp;

    QMutex mutex; // 互斥锁
};




namespace Ui {
class page2;
}

class page2 : public QWidget
{
    Q_OBJECT

public:
    explicit page2(QWidget *parent = nullptr);
    ~page2();

private slots:
    void on_pushButton_back_clicked();
    void updateSR04Label(const QString &text);
    void updateDHT11Labels(const QString &tempText, const QString &humiText);
    void on_checkBox_stateChanged(int arg1);

private:
    Ui::page2 *ui;
    QMainWindow *mainWindow; // 用于管理主窗口的指针
};










#endif // PAGE2_H
