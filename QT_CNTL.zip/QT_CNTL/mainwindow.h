#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QMessageBox>
#include <QMessageAuthenticationCode>
#include<QDebug>

#include "led.h"
#include "sr04.h"
#include "dht11.h"
#include "page1.h"
#include "page2.h"
#include "page3.h"
#include "kimichat.h"

#include "mqttclient.h"
#include <QJsonParseError>
#include <QJsonObject>
#include <QSerialPort>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QLabel *label;
    QPushButton *camera;
    QPushButton *distance;
    QPushButton *kimichat;
    QPushButton *sg90;
    QPushButton *motor;
    QCheckBox *led;
    bool LEDSwitch = true;
    QPushButton *subscribeButton;


    bool isSubscribed = false;
    QJsonObject jsonObj;




public slots:

private slots:

    void on_camera_clicked();

    void on_sr04_clicked();

    void on_led_stateChanged();

    void on_subscribeButton_clicked();

    void connectSuccessSlot();
    void recvMessageSlot(const QByteArray &message, const QMqttTopicName &topic);

    void on_kimichat_clicked();

    void on_sg90_clicked();

private:
    Ui::MainWindow *ui;
//    page1 *ppage1 = NULL;

    QMqttClient *m_client;
    QString m_strPubTopic1 = "led/control";
    QString m_strPubTopic2 = "sg90";
    QString m_strPubTopic3 = "sensors";



};




#endif // MAINWINDOW_H
