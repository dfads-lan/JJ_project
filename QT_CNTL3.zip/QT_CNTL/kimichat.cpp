#include "kimichat.h"
#include "ui_kimichat.h"

KimiChat::KimiChat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::KimiChat)
{
    ui->setupUi(this);

    // 初始化网络请求管理器
    manager = new QNetworkAccessManager(this);
    connect(manager, &QNetworkAccessManager::finished, this, &KimiChat::onReplyFinished);


//    ui->lineEdit->setVisible(false);

//    keyboad = new QQuickWidget(this);
//    keyboad->setResizeMode(QQuickWidget::SizeRootObjectToView);
//    keyboad->setSource(QUrl("qrc:/file/VisualKeyTool.qml"));
//    keyboad->setFixedSize(this->width(),this->height()/2);
//    keyboad->move(0, this->height()- keyboad->height());

}

KimiChat::~KimiChat()
{
    delete ui;
}

void KimiChat::on_sendButton_clicked()
{
    // 获取用户输入的问题
    QString question = ui->lineEdit->text();
    if (question.isEmpty()) {
        QMessageBox::warning(this, "警告", "请输入问题！");
        return;
    }

    // 构造JSON请求体
    QJsonObject json;
    json["model"] = "deepseek-r1:1.5B";  // 模型名称
    json["prompt"] = question;          // 提示文本
    json["stream"] = true;              // 是否以流式返回


    QByteArray data = QJsonDocument(json).toJson();

    // 构造请求
    QNetworkRequest request(QUrl("http://localhost:11434/api/generate"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // 发送POST请求
    QNetworkReply* reply = manager->post(request, data);

    // 使用QEventLoop等待响应
    QEventLoop loop;
    connect(reply, &QNetworkReply::readyRead, &loop, &QEventLoop::quit);
    loop.exec();

    // 读取流式响应
    QTextStream stream(reply);
    QString responseText;
    while (!stream.atEnd()) {
        QString line = stream.readLine();
        responseText += line + "\n";
    }

    ui->textEdit->append("Deepseek: " + responseText);  // 显示Kimi的回复
}



void KimiChat::onReplyFinished(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError) {
        // 获取响应数据
        QByteArray response = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(response);
        if (!doc.isNull() && doc.isObject()) {
            QJsonObject obj = doc.object();
            QString replyText = obj["choices"].toArray()[0].toObject()["message"].toObject()["content"].toString();
            ui->textEdit->append("Kimi: " + replyText);  // 显示Kimi的回复
        } else {
            ui->textEdit->append("Kimi: 无法解析响应数据");
        }
    } else {
        QString errorString = reply->errorString();
        ui->textEdit->append("Kimi: 网络请求失败：" + errorString);
        if (errorString.contains("Not Found")) {
            ui->textEdit->append("请检查API地址是否正确，或联系Kimi官方获取帮助。");
        } else if (errorString.contains("Connection refused")) {
            ui->textEdit->append("网络连接被拒绝，请检查网络配置或代理设置。");
        } else {
            ui->textEdit->append("其他错误，请检查网络或API Key是否正确。");
        }
    }
}

void KimiChat::on_pushButton_back_clicked()
{
    this->close();
    MainWindow *s = new MainWindow();
    s->show();
}
