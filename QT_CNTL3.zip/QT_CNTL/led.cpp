#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <QDebug>

#include "led.h"
static int fd1,fd2;

#define LED_TRIGGER "/sys/class/leds/sys-led/trigger"
#define LED_BRIGHTNESS "/sys/class/leds/sys-led/brightness"

void led_init(void)
{
    fd1 = open(LED_TRIGGER, O_RDWR);
    if (fd1 < 0)
    {
        qDebug()<<"open led failed";
    }

    fd2 = open(LED_BRIGHTNESS, O_RDWR);
    if (fd2 < 0)
    {
        qDebug()<<"open led failed";
    }

    qDebug()<<"open led successfully " << endl;

}

void led_control(int on)
{

    if (on)
    {
        write(fd1, "none", 4); //先将触发模式设置为 none
        write(fd2, "1", 1); //点亮 LED
    }
    else
    {
        write(fd1, "none", 4); //先将触发模式设置为 none
        write(fd2, "0", 1); //LED 灭
    }
}
