#ifndef MQTTCLIENT_H
#define MQTTCLIENT_H


#include <QObject>
#include <QtMqtt/QMqttClient>

class MqttClient : public QObject
{
    Q_OBJECT
public:
    explicit MqttClient(QObject *parent = nullptr);
    void connectToServer(const QString &host, quint16 port);
    void subscribe(const QString &topic);
    void publish(const QString &topic, const QString &message);

signals:
    void messageReceived(const QString &topic, const QString &message);

private slots:
    void onConnected();
    void onMessageReceived(const QByteArray &message, const QMqttTopicName &topic);

private:
    QMqttClient *m_client;
};


#endif // MQTTCLIENT_H
