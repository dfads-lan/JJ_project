#ifndef PAGE3_H
#define PAGE3_H

#include <QWidget>
#include <QSlider>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>

// 不再需要 <QSerialPort> 与串口相关头文件
#include "spi_wrapper.h"   // 新增

namespace Ui {
class page3;
}

class page3 : public QWidget
{
    Q_OBJECT
public:
    explicit page3(QWidget *parent = nullptr);
    ~page3();

signals:
    void back();

private slots:
    void on_slider_valueChanged(int value);
    void on_pushButton_back_clicked();

private:
    Ui::page3 *ui;
    SpiWrapper spi;   // 替换原来的 QSerialPort
};

#endif // PAGE3_H
