#include "spi_wrapper.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <QDebug>

SpiWrapper::SpiWrapper(QObject *parent) : QObject(parent) {}
SpiWrapper::~SpiWrapper() { close(); }

bool SpiWrapper::open(const char *device, uint32_t speed, uint8_t bits)
{
    fd = ::open(device, O_RDWR);
    if (fd < 0) {
        qCritical() << "Cannot open SPI device" << device;
        return false;
    }

    uint8_t  mode   = SPI_MODE_0;
    uint8_t  lsb    = 0;                 // MSB first
    ioctl(fd, SPI_IOC_WR_MODE,  &mode);
    ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
    ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
    return true;
}

void SpiWrapper::close()
{
    if (fd >= 0) { ::close(fd); fd = -1; }
}

bool SpiWrapper::write(const QByteArray &tx)
{
    if (fd < 0) return false;
    return ::write(fd, tx.constData(), tx.size()) == tx.size();
}

bool SpiWrapper::transfer(const QByteArray &tx, QByteArray &rx)
{
    if (fd < 0) return false;
    rx.resize(tx.size());

    struct spi_ioc_transfer tr{};
    tr.tx_buf        = (uintptr_t)tx.constData();
    tr.rx_buf        = (uintptr_t)rx.data();
    tr.len           = tx.size();
    tr.speed_hz      = 0;       // 沿用 open 时设置的速率
    tr.bits_per_word = 0;       // 沿用
    tr.delay_usecs   = 0;
    tr.cs_change     = 0;

    int ret = ioctl(fd, SPI_IOC_MESSAGE(1), &tr);
    return ret == 1;
}
