#ifndef PHOTO_H
#define PHOTO_H

#include <QWidget>
#include <QDir>
#include <QMessageBox>

namespace Ui {
class photo;
}

class photo : public QWidget
{
    Q_OBJECT

public:
    explicit photo(QWidget *parent = nullptr);
    ~photo();

signals:
    void back();

private slots:
    void on_pushButton_up_clicked();

    void on_pushButton_next_clicked();

    void on_pushButton_back_clicked();

    void on_delete_2_clicked();
    void loadAndDisplayImage(int newIndex);
private:
    Ui::photo *ui;
    QDir dir; // 目录对象
    QStringList fileList; // 存储文件列表
    int currentIndex = 0; // 当前显示的文件索引

};

#endif // PHOTO_H
