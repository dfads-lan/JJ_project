#ifndef SR04_H
#define SR04_H


void sr04_init(void);
int sr04_read(int &ns);
int sr04_close(void);






#endif // SR04_H
