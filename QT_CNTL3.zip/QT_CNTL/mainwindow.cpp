#include "mainwindow.h"
#include "ui_mainwindow.h"



void init_all(void)
{

    led_init();
//    sr04_init();

}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    init_all();

    label = ui->label;
    camera = ui->camera;
    distance = ui->sr04;
    kimichat = ui->kimichat;
    sg90 = ui->sg90;
    led = ui->led;

    led->setCheckState(Qt::Unchecked);
    label->setText("The LED is off");


    this->ppage1 = new page1;
    this->ppage2 = new page2;
    this->ppage3 = new page3;


    connect(this->ppage1, &page1::back,[=](){
        this->ppage1->hide();
        this->show();
    });
    connect(this->ppage2, &page2::back,[=](){
        this->ppage2->hide();
        this->show();
    });
    connect(this->ppage3, &page3::back,[=](){
        this->ppage3->hide();
        this->show();
    });


    connect(ui->camera, &QPushButton::clicked, [=]()
   {
       this->hide();
       this->ppage1->show();
   });
    connect(ui->sr04, &QPushButton::clicked, [=]()
   {
       this->hide();
       this->ppage2->show();
   });
    connect(ui->sg90, &QPushButton::clicked, [=]()
   {
       this->hide();
       this->ppage3->show();
   });



    m_client = new QMqttClient(this);
    m_client->setHostname("test.mosquitto.org");
    m_client->setPort(1883);


    connect(m_client, &QMqttClient::connected, this, &MainWindow::connectSuccessSlot);
    connect(m_client, &QMqttClient::disconnected, this, [this]()
    {
        QMessageBox::warning(this, "连接提示", "连接失败");
        ui->subscribeButton->setText("连接服务器");
    });


}

MainWindow::~MainWindow()
{


    delete ui;

}


void MainWindow::on_camera_clicked()
{
//    this->close();
//    page1 *s = new page1();
//    s->show();
}

void MainWindow::on_sr04_clicked()
{
//    this->close();
//    page2 *l = new page2();
//    l->show();

}

void MainWindow::on_kimichat_clicked()
{
    this->hide();
    KimiChat *m = new KimiChat();
    m->show();
}

void MainWindow::on_sg90_clicked()
{
//    this->close();
//    page3 *p = new page3();
//    p->show();
}


void MainWindow::on_led_stateChanged()
{
    led_control(LEDSwitch);
    //qDebug()<<LEDSwitch<<endl;
    if(LEDSwitch) label->setText("The LED is already on");
    else label->setText("The LED is off");
    LEDSwitch = !LEDSwitch;

}


void MainWindow::on_subscribeButton_clicked()
{
//    m_client->connectToHost();

    if (m_client->state() == QMqttClient::Connected) // 使用 QMqttClient 的状态枚举
        {
            // 如果已经连接，执行断开操作
            m_client->disconnectFromHost();
            // 可选：更新按钮文本或状态提示
//             ui->subscribeButton->setText("连接服务器");
//             QMessageBox::information(this, "提示", "已断开连接");
             ui->label_2->setText(" ");
        }
        else
        {
            // 如果未连接，执行连接操作
            m_client->connectToHost();
            // 可选：更新按钮文本或状态提示
//             ui->subscribeButton->setText("断开服务器");
//             QMessageBox::information(this, "提示", "正在尝试连接...");
        }
}

/* 连接服务器成功槽函数  */
void MainWindow::connectSuccessSlot()
{
    QMessageBox::information(this, "连接提示", "连接成功");
    ui->subscribeButton->setText("断开服务器");

    m_client->subscribe(m_strPubTopic1);
    m_client->subscribe(m_strPubTopic2);
    m_client->subscribe(m_strPubTopic3);

    /* 消息接受成功槽函数 */
    connect(m_client, &QMqttClient::messageReceived, this, &MainWindow::recvMessageSlot);

    connect(m_client, &QMqttClient::disconnected, this, [this]()
    {
        QMessageBox::warning(this, "连接提示", "服务器断开");
    });

}
/* 接收控制槽函数  */
void MainWindow::recvMessageSlot(const QByteArray &message, const QMqttTopicName &topic)
{
    if (topic.name() == m_strPubTopic1) {
           QString msg = message.trimmed();
           if (msg == "on") {
               // 打开 LED
               system("echo 1 > /sys/class/leds/sys-led/brightness"); // 替换为实际的 GPIO 控制命令
           } else if (msg == "off") {
               // 关闭 LED
               system("echo 0 > /sys/class/leds/sys-led/brightness"); // 替换为实际的 GPIO 控制命令
           } else {
               qDebug() << "未知的控制指令：" << msg;
           }
       }
    if (topic.name() == m_strPubTopic2) {
        QString msg = message.trimmed();
        bool ok;
        int angle = msg.toInt(&ok); // 将消息转换为整数，并检查是否成功转换
        if (ok && angle >= 0 && angle <= 180) {
            // 控制SG90舵机
            this->ppage3->on_slider_valueChanged(angle);
//            if (serialPort.open(QIODevice::WriteOnly)) {
//                QByteArray data;
//                data.append(static_cast<char>(angle));
//                serialPort.write(data); // 发送数据
//                serialPort.close();
//            } else {
//                qDebug() << "无法打开串口：" << serialPort.portName();
//            }
        } else {
            qDebug() << "未知的控制指令或角度超出范围：" << msg;
        }
    }
    if (topic.name() == m_strPubTopic3) {
           QString msg = message.trimmed();
           if (msg == "dht11") {
               dht11_init();
               if (0 == dht11_read(&temp, &humi))
               {
                   QByteArray tempPayload = QByteArray::number(temp);
                   QByteArray humiPayload = QByteArray::number(humi);
                   // 发布温度和湿度数据
                   QMqttTopicName B("temp");
                   QMqttTopicName C("humi");
                   m_client->publish(B, tempPayload);
                   m_client->publish(C, humiPayload);
                }
               dht11_close();
               }else if (msg == "sr04") {
               sr04_init();
               int distance = 0;
               if (sr04_read(distance) == 0)
               {
                   // 将距离转换为字符串
                    QByteArray distancePayload = QByteArray::number(distance * 340 / 2 / 1000000);
                    // 发布距离数据
                    QMqttTopicName A("distance");
                    m_client->publish(A, distancePayload);
               }
               sr04_close();
           }else {
               qDebug() << "未知的控制指令：" << msg;
           }
       }

       /* 显示接收到的信息到文本框上 */
    QString str = topic.name() + QString(message);
    ui->label_2->setText(str);

}








