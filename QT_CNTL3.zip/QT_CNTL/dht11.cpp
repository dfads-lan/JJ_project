#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>

#include <errno.h>
#include <QDebug>

#include "dht11.h"
static int fd1;
char humi_data[20];
char temp_data[20];
char humi;
char temp;


/* dht11初始化函数 */
void dht11_init(void)
{
    fd1 = open("/dev/xf_dht11", O_RDWR);
    if (fd1 < 0)
    {
        qDebug()<<"open /dev/dht11 failed" << endl;
    }
    else
        qDebug()<<"open /dev/dht11 successfully " << endl;
}

/* dht11读函数 */
int dht11_read(char *humi, char *temp)
{
    unsigned char data[4];
    int ret ;

    ret = read(fd1, data, 4);

    if (ret < 0)
    {
        qDebug() <<"read /dev/dht11 failed" << endl ;
        return -1;
    }
//    qDebug() <<"read /dev/dht11 successfully " << endl ;
    *temp = data[0];
    *humi = data[2];


    return 0;

}

int dht11_close()
{
    close(fd1);
    return 0;
}

