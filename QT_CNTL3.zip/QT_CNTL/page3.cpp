#include "page3.h"
#include "ui_page3.h"

page3::page3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::page3)
{
    ui->setupUi(this);

    // 打开 SPI 设备（
    if (!spi.open("/dev/sg90", 1000000)) {
        QMessageBox::critical(this, "Error", "Failed to open SPI device");
    }

    connect(ui->pushButton_back, &QPushButton::clicked,
            this, &page3::back);
}

page3::~page3()
{
    delete ui;
}

void page3::on_slider_valueChanged(int value)
{
    ui->label->setText(QString("Angle: %1").arg(value));

    QByteArray tx(1, static_cast<char>(value));
    if (!spi.write(tx)) {
        qWarning() << "SPI write failed!";
    }
}

void page3::on_pushButton_back_clicked()
{

}
