#ifndef SPI_WRAPPER_H
#define SPI_WRAPPER_H

#include <QObject>
#include <linux/spi/spidev.h>

class SpiWrapper : public QObject
{
    Q_OBJECT
public:
    explicit SpiWrapper(QObject *parent = nullptr);
    ~SpiWrapper();

    bool open(const char *device, uint32_t speed = 1000000, uint8_t bits = 8);
    void close();
    bool write(const QByteArray &tx);      // 只管发
    bool transfer(const QByteArray &tx, QByteArray &rx); // 全双工

private:
    int fd = -1;
};

#endif // SPI_WRAPPER_H
