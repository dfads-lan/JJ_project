#include "page2.h"
#include "ui_page2.h"


SR04Thread *sr04Thread;
DHT11Thread *dht11Thread;

volatile bool dht11_running = true; // 线程运行标志
volatile bool sr04_running = true; // 线程运行标志
//int Temp_data[51] = {0};  // 温度数组
//int Humi_data[51] = {0};  // 湿度数组


page2::page2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::page2)
{
    ui->setupUi(this);

//    // 设置关闭时自动删除
//    this->setAttribute(Qt::WA_DeleteOnClose);

    // 创建 SR04 线程并启动
    sr04Thread = new SR04Thread(this);
    sr04Thread->SetLabel_sr04(ui->sr04_label);
    sr04Thread->start();

    // 创建 SR04 线程并启动
    dht11Thread = new DHT11Thread(this);
    dht11Thread->SetLables(ui->label_4,ui->label_5);
    dht11Thread->start();


    // 连接信号与槽
    connect(ui->checkBox, &QCheckBox::stateChanged, dht11Thread, &DHT11Thread::updateDHT11Data);
    connect(ui->checkBox, &QCheckBox::stateChanged, sr04Thread, &SR04Thread::updateSR04Data);

    connect(sr04Thread, &SR04Thread::resultReady, this, &page2::updateSR04Label);
    connect(dht11Thread, &DHT11Thread::resultReady, this, &page2::updateDHT11Labels);

    connect(ui->pushButton_back, &QPushButton::clicked,[=](){
        emit this->back();
    });
    // 初始化主窗口指针
//    mainWindow = nullptr;
}

page2::~page2()
{
    // 停止 SR04 线程
    sr04Thread->quit();
    sr04Thread->wait();
    delete sr04Thread;
    // 停止 DHT11 线程
    dht11Thread->quit();
    dht11Thread->wait();
    delete dht11Thread;
    sr04_running = false;
    dht11_running = false;
    delete ui;
        qDebug() << "xigouhanshu!!!" ;
}

void page2::on_pushButton_back_clicked()
{

//    // 停止线程
    sr04Thread->quit();
    sr04Thread->wait();

    dht11Thread->quit();
    dht11Thread->wait();
    sr04_running = false;
    dht11_running = false;
//    this->close(); // 关闭当前页面

//    // 显示主窗口
//    if (!mainWindow) {
//        mainWindow = new MainWindow();
//    }
//    mainWindow->show();
}

/* SR04接受按钮改变的槽函数 */
void SR04Thread::updateSR04Data(int state)
{
    sr04_running = (state == Qt::Checked) ? false : true;
    qDebug() << "SR04Thread running state:" << sr04_running;
}
/* dht11接受按钮改变的槽函数  */
void DHT11Thread::updateDHT11Data(int state)
{
    dht11_running = (state == Qt::Checked) ? true : false;
    qDebug() << "DHT11Thread running state:" << dht11_running;
}




/* 连接dht11标签 */
void DHT11Thread::SetLables(QLabel *labelHumi, QLabel *labelTemp)
{
    this->labelHumi = labelHumi;
    this->labelTemp = labelTemp;
}
// 连接sr04标签
void SR04Thread::SetLabel_sr04(QLabel *label)
{
    sr04_label = label;
}


// SR04 线程实现
void SR04Thread::run()
{
    int distance = 0;
    while (sr04_running)
    {
        sr04_init();
        int ret = sr04_read(distance);

        if (ret == 0)
        {
//            qDebug() << "distance" << distance * 340 / 2 / 1000000;
            QString distanceText = QString("距离: %1 mm").arg(distance * 340 / 2 / 1000000);
            emit resultReady(distanceText); // 发送结果准备好的信号
        }
        else
        {
            sr04_close();
            emit resultReady("N/A"); // 发送失败信息
            break;
        }
        sr04_close();
        msleep(500); // 线程休眠 0.5 秒
    }
}

/* DHT11线程 */
void DHT11Thread::run(){

    while(1){
        msleep(500);
        mutex.lock();  //加锁

        if(!dht11_running)
        {
            mutex.unlock(); //解锁
            break;
        }else
        {
            dht11_init();
            if (0 == dht11_read(&temp, &humi))
            {

                sprintf(temp_data, "%d", temp);
                labelHumi->setText(temp_data);   //显示到labelHumi标签上
                sprintf(humi_data, "%d", humi);
                labelTemp->setText(humi_data);   //显示到labelTemp标签上
               /* 发送结果准备好的信号 */
                emit resultReady(temp_data,humi_data);

            }
            else {
                dht11_close();
                break;
            }
            dht11_close();
            mutex.unlock();
        }

    }
}

void SR04Thread::stop()
{
    sr04_running = false;
}
void DHT11Thread::stop()
{
    dht11_running = false;
}



void page2::updateSR04Label(const QString &text) {
    ui->sr04_label->setText(text); // 更新 SR04 标签
}

void page2::updateDHT11Labels(const QString &tempText, const QString &humiText) {
    ui->label_4->setText(tempText); // 更新温度标签
    ui->label_5->setText(humiText); // 更新湿度标签
}

void page2::on_checkBox_stateChanged(int arg1)
{
    if (arg1 == Qt::Checked)
    {
        sr04Thread->stop(); // 停止 SR04 线程
        dht11Thread->start(); // 启动 DHT11 线程
        ui->label_6->setText("当前线程：DHT11");
    }
    else
    {
        dht11Thread->stop(); // 停止 DHT11 线程
        sr04Thread->start(); // 启动 SR04 线程
        ui->label_6->setText("当前线程：SR04");
    }
}
