#include "stm32f10x.h"

#define UART1_RX_BUFFER_SIZE 1

volatile uint8_t uart1_rx_buffer[UART1_RX_BUFFER_SIZE];
volatile uint8_t uart1_rx_index = 0;
volatile uint8_t uart1_rx_data = 0;
volatile uint8_t new_data_received = 0;

void RCC_Configuration(void);
void GPIO_Configuration(void);
void USART1_Configuration(void);
void TIM2_Configuration(void);
void NVIC_Configuration(void);

void RCC_Configuration(void)
{
    // 使能GPIOA、USART1、AFIO和TIM2时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
}

void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // 配置USART1_TX (PA9)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置USART1_RX (PA10)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置TIM2_CH1 (PA0)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void USART1_Configuration(void)
{
    USART_InitTypeDef USART_InitStructure;

    // 配置USART1
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    // 使能USART1
    USART_Cmd(USART1, ENABLE);

    // 使能USART1接收中断
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
}

void TIM2_Configuration(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    // 配置TIM2
    TIM_TimeBaseStructure.TIM_Period = 20000 - 1; // 20ms周期
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1; // 预分频值
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    // 配置TIM2通道1为PWM输出
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 1500; // 默认脉冲宽度1500us
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM2, &TIM_OCInitStructure);

    // 使能TIM2
    TIM_Cmd(TIM2, DISABLE); // 初始时禁用定时器，避免PWM信号输出
}

void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    // 配置USART1中断
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uart1_rx_buffer[uart1_rx_index++] = USART_ReceiveData(USART1);
        if (uart1_rx_index >= UART1_RX_BUFFER_SIZE)
        {
            uart1_rx_index = 0;
        }
        uart1_rx_data = uart1_rx_buffer[0];
        new_data_received = 1; // 标记接收到新数据
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

void UpdateServoPosition(uint8_t angle)
{
    uint16_t pulse_width = (angle * 11.11) + 500; // 计算脉冲宽度
    TIM_SetCompare1(TIM2, pulse_width); // 更新PWM脉冲宽度
    TIM_Cmd(TIM2, ENABLE); // 启动定时器，输出PWM信号
}

// 初始化SysTick定时器
void SysTick_Init(void)
{
    // 配置SysTick定时器，每1ms中断一次
    SysTick_Config(SystemCoreClock / 1000); // SystemCoreClock是系统时钟频率
}

// 延迟函数，单位为毫秒
void Delay_ms(uint32_t ms)
{
    for (uint32_t i = 0; i < ms; i++)
    {
        // 等待SysTick计数器溢出（1ms）
        while (!(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));
    }
}

int main(void)
{
    // 系统配置
	SysTick_Init();
    RCC_Configuration();
    GPIO_Configuration();
    USART1_Configuration();
    TIM2_Configuration();
    NVIC_Configuration();

    while (1)
    {
        if (new_data_received)
        {
            UpdateServoPosition(uart1_rx_data); // 更新舵机角度
			Delay_ms(100);// 延迟2秒
            new_data_received = 0; // 清除标记
			TIM_Cmd(TIM2, DISABLE);
        }
    }

	
	
}